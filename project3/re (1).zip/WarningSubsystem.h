#ifndef WARNINGSUBSYSTEM_H
#define WARNINGSUBSYSTEM_H

void WarningAlarmSubsystemFunction(void* data);

#endif // WARNINGSUBSYSTEM_H
