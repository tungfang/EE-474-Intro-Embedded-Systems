#include "DisplaySubsystem.h"
#include "globals.h"

void DisplaySubsystemFunction(void* data) {
    DisplaySubsystemData* displayData = (DisplaySubsystemData*) data;
}
