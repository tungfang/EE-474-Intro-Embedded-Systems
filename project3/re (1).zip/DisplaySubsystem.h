#ifndef DISPLAYSUBSYSTEM_H
#define DISPLAYSUBSYSTEM_H

void DisplaySubsystemFunction(void* data);


#endif // DISPLAYSUBSYSTEM_H
