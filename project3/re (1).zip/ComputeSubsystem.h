#ifndef COMPUTESUBSYSTEM_H
#define COMPUTESUBSYSTEM_H

void ComputeSubsystemFunction(void* data);

#endif // COMPUTESUBSYSTEM_H
