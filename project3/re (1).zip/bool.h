#ifndef BOOL_H
#define BOOL_H


enum _myBool { FALSE = 0, TRUE = 1 };
typedef enum _myBool Bool;

#endif // BOOL_H
