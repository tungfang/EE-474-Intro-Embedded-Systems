#ifndef STATUSSUBSYSTEM_H
#define STATUSSUBSYSTEM_H


void StatusSubsystemFunction(void* data);

#endif // STATUSSUBSYSTEM_H
