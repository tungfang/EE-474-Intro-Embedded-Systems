#ifndef MEASURESUBSYSTEM_H
#define MEASURESUBSYSTEM_H
#include "bool.h"

void MeasureSubsystemFuction(void* data);

#endif // MEASURESUBSYSTEM_H
