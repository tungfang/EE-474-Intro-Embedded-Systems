#include "StatusSubsystem.h"
#include "globals.h"

void StatusSubsystemFunction(void* data)
{
    StatusSubsystemData* statusData = (StatusSubsystemData*) data;
}
