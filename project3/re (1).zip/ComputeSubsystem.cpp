#include "ComputeSubsystem.h"

void ComputeSubsystemFunction(void* data)
{
    ComputeSubsystemData* computeData = (ComputeSubsystemData*) data;
}
