#include "WarningSubsystem.h"
#include "globals.h"


void WarningAlarmSubsystemFunction(void* data)
{
    WarningAlarmSubsystemData* warningData = (WarningAlarmSubsystemData*) data;
}
