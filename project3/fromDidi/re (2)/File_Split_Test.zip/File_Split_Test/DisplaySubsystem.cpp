#include "DisplaySubsystem.h"
#include <Arduino.h>
#include "bool.h"
#include "circularBuffer.h"

void DisplaySubsystemFunction(void* data) {
    DisplaySubsystemData* displayData = (DisplaySubsystemData*) data;
    
}