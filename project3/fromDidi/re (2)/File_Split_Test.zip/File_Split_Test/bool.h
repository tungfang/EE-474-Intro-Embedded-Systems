#ifndef BOOL_H_INCLUDED
#define BOOL_H_INCLUDED

enum _myBool {FALSE = 0, TRUE = 1};
typedef enum _myBool Bool;

#endif // BOOL_H_INCLUDED
